//
// Created by cheng on 4/24/2020.
//
#include "LandBasedRobot.h"

void rwa3::LandBasedRobot::GoUp(int x_, int y_) {
    std::cout << "LandBasedRobot::GoUp is called\n";
}// Move the robot up in the maze.

void rwa3::LandBasedRobot::GoDown(int x_, int y_) {
    std::cout << "LandBasedRobot::GoDown is called\n";
}// Move the robot down in the maze.

void rwa3::LandBasedRobot::TurnLeft(int x_, int y_) {
    std::cout << "LandBasedRobot::TurnLeft is called\n";
}// Move the robot left in the maze.
void rwa3::LandBasedRobot::TurnRight(int x_, int y_) {

} // Move the robot right in the maze.
void rwa3::LandBasedRobot::PickUp(std::string target) {
    std::cout << "LandBasedRobot::PickUp is called\n";
} // Arm picks up an object.

void rwa3::LandBasedRobot::Release(std::string target) {
    std::cout << "LandBasedRobot::Release is called\n";
}

